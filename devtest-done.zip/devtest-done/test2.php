<?php
/**
 * QUESTION 2
 *
 * Using the data stored in the database
 * show a list of products with their prices
 * grouped by category.
 * The categories should be listed in alphabetical order.
 * The products within those categories should also be listed in alphabetical order.
 * Products with no category will be categorized as "Uncategorized".
 * If there are no results, then it should just say "There are no results available."
 *
 * Please make sure your code runs as effectively as it can.
 *
 * See test2.html for desired result.
 */
?>
<?php
// $con holds the connection
require_once('db.php');

$string = "SELECT COALESCE(c.category, 'Uncategorized') AS category, p.product, p.price
             FROM products p LEFT JOIN categories c ON p.category_id = c.id
           ORDER BY CASE WHEN c.category IS NULL THEN 1 ELSE 0 END, c.category ASC, p.product ASC";

$result = mysqli_query( $con, $string );
$memory = [];

ob_start();


while ( $record = mysqli_fetch_assoc($result) )
{
    $sector = $record[ 'category' ];
    $prduct = $record[ 'product' ];
    $priced = $record[ 'price' ];
    $dejavu = in_array( $sector, $memory );


    if ( !strpos($priced,".") )
    { $priced .= ".00"; };


    if ( !$dejavu )
    {
        if ( count($memory) > 0 )
        { echo "\n</table>\n"; };

        $memory[] = $sector;

        echo "<h2>$sector</h2>\n<table>".
             "\n<tr><th>Product</th><th class=\"price\">Price</th></tr>";
    };


    echo "\n<tr><td>$prduct</td><td class=\"price\">R $priced</td></tr>";
};


$output = ob_get_clean();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Test2</title>
    <style>
        table
        {
            width: 400px;
        }

        th
        {
            text-align: left;
        }

        .price
        {
            width: 100px;
            text-align: right;
        }
    </style>
</head>
<body>
<h1>Products</h1>
<?=$output?>
</body>
</html>
