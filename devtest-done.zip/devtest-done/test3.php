<?php
/**
 * QUESTION 3
 *
 * For each month that had sales, show a list of customers ordered by who spent the most to who spent least.
 * If the totals are the same then sort by customer.
 * If a customer has multiple products then order those products alphabetically.
 * Months with no sales should not show up.
 * Show the name of the customer, what products they bought and the total they spent.
 * Only show orders with the "Payment received" and "Dispatched" status.
 * If there are no results, then it should just say "There are no results available."
 *
 * Please make sure your code runs as effectively as it can.
 *
 * See test3.html for desired result.
 */
?>
<?php
//$con holds the connection
require_once('db.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Test3</title>
</head>
<body>
<h1>Top Customers per Month</h1>


<?php
$query = "
    SELECT
        DATE_FORMAT(o.order_date, '%Y-%m') AS period,
        DATE_FORMAT(o.order_date, '%M %Y') AS sector,
        o.user_id,
        CONCAT(u.first_name, ' ', u.last_name) AS person,
        p.product AS artixx,
        p.price AS amount
    FROM orders o
    JOIN statuses s ON o.order_status_id = s.id
    JOIN users u ON o.user_id = u.id
    JOIN order_items oi ON o.id = oi.order_id
    JOIN products p ON oi.product_id = p.id
    WHERE s.status_name IN ('Payment Received', 'Dispatched')
    ORDER BY period, person, artixx
";


$linked = mysqli_query($con, $query);


if (mysqli_num_rows($linked) === 0)
{
    echo "<p>There are no results available.</p>";
}
else
{
    $output = [];


    while ($row = mysqli_fetch_assoc($linked))
    {
        $period = $row['period'];
        $sector = $row['sector'];
        $person = $row['person'];
        $artixx = $row['artixx'];
        $amount = (float)$row['amount'];


        if (!isset($output[$period]))
        {
            $output[$period] = ['sector' => $sector, 'actors' => []];
        };


        if (!isset($output[$period]['actors'][$person]))
        {
            $output[$period]['actors'][$person] = [
                'artixx' => [],
                'amount' => 0
            ];
        };


        $output[$period]['actors'][$person]['artixx'][] = $artixx;
        $output[$period]['actors'][$person]['amount'] += $amount;
    }


    ksort($output);


    foreach ($output as $period => $group)
    {
        echo "<h2>{$group['sector']}</h2>";
        echo '<table width="800"><tbody>
                <tr>
                    <th width="200" align="left">Customer</th>
                    <th width="400" align="left">Products Bought</th>
                    <th width="200" align="right">Total</th>
                </tr>';

        $actors = $group['actors'];


        uasort($actors, function ($a, $b) use ($actors)
        {
            if ($a['amount'] === $b['amount'])
            {
                return strcmp(array_search($a, $actors), array_search($b, $actors));
            }

            return $b['amount'] <=> $a['amount'];
        });


        foreach ($actors as $person => $bundle)
        {
            sort($bundle['artixx']);

            $lines = implode('<br>', array_map('htmlspecialchars', $bundle['artixx']));
            $total = number_format($bundle['amount'], 2, '.', ',');

            echo "<tr>
                    <td valign='top'>{$person}</td>
                    <td>{$lines}</td>
                    <td valign='bottom' align='right'>R {$total}</td>
                </tr>";
        }


        echo '</tbody></table>';
    }
}
?>


</body>
</html>
