<?php
$con = mysqli_connect("localhost","root","v0rt3x","devtest");

if (mysqli_connect_errno())
{
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
